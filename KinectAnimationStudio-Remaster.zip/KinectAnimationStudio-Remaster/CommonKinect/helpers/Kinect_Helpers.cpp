#include "Kinect_helpers.h"
#include "UI_helpers.h"



/// <summary>
/// Initializes the default Kinect sensor
/// </summary>
/// <returns>indicates success or failure</returns>
HRESULT InitializeDefaultSensor(IKinectSensor **kSensor) {

	HRESULT hr;

	hr = GetDefaultKinectSensor(kSensor);
	if (FAILED(hr))
	{
		return hr;
	}
	
	if (!(*kSensor))
	{
		UI_Printf("No ready Kinect found!");
		return E_FAIL;
	} else {
		hr = (*kSensor)->Open(); // Open Sensor
	}

	return hr;

}


/// <summary>
/// Close the default Kinect sensor
/// </summary>
/// <returns>indicates success or failure</returns>
HRESULT CloseDefaultSensor(IKinectSensor *kSensor) {
	
	HRESULT hr = S_OK;
	// close the Kinect Sensor
	if (kSensor)
	{
		hr = kSensor->Close();
	}
	return hr;
}


HRESULT RetrieveKinectSensorStructures(IKinectSensor *kSensor,ICoordinateMapper **coordinateMapper, IBodyFrameReader **bodyFrameReader) {
	// The sensor is NULL whenever no Kinect is connected or Open() failed:
	// the app still calls init() in that case, so this must not dereference
	// it. Returning an error leaves the out parameters NULL, which the
	// callers already test.
	if (!kSensor)
		return E_POINTER;

	HRESULT hr;
	BOOLEAN isOpen = FALSE;
	hr = kSensor->get_IsOpen(&isOpen);
	if (FAILED(hr))
		return hr;
	if (!isOpen)
		return E_FAIL;

	// Initialize the Kinect and get coordinate mapper and the body reader
	IBodyFrameSource* pBodyFrameSource = NULL;

	hr = kSensor->Open();

	if (SUCCEEDED(hr) && coordinateMapper)
	{
		hr = kSensor->get_CoordinateMapper(coordinateMapper);
	}

	if (SUCCEEDED(hr))
	{
		hr = kSensor->get_BodyFrameSource(&pBodyFrameSource);
	}

	// pBodyFrameSource is still NULL when get_BodyFrameSource failed, so the
	// reader may only be opened when it was actually obtained.
	if (SUCCEEDED(hr) && pBodyFrameSource && bodyFrameReader)
	{
		hr = pBodyFrameSource->OpenReader(bodyFrameReader);
	}

	if (pBodyFrameSource)
		pBodyFrameSource->Release();
	return hr;
}