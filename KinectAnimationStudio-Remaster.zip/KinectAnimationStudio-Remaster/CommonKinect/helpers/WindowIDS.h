// Define default window IDS to be used by this program

#ifndef __UI_WINDOW_IDS__
#define __UI_WINDOW_IDS__

#define EXPORT_TO_BUTTON  1050
#define RECORD_BUTTON    1051
#define STOP_RECORD_BUTTON      1052

#define EXPORT_TO_EDITBOX 1053
#define EXECUTE_STATUS      1054
#define VIEW_STATUS			1055
#define TIMELINE_WINDOW		1056

// Playback & controls
#define PLAY_BUTTON         1060
#define CLEAR_BUTTON        1061
#define SMOOTH_SLIDER       1062
#define SMOOTH_VALUE        1063
#define LOOP_CHECK          1064
#define GHOST_CHECK         1065
#define PAUSE_CHECK         1066
#define TAKE_INFO_LABEL     1067
#define SMOOTH_LABEL        1068
#define CAPTURE_LABEL       1069
#define PLAYBACK_LABEL      1070
#define DEPTH_CHECK         1071
#define CAMERA_CHECK        1072
#define FLOOR_CHECK         1073
#define GESTURE_CHECK       1074

// Retarget workspace
#define IMPORT_FBX_BUTTON        1080
#define AUTOMAP_BUTTON           1081
#define RETARGET_PLAY_BUTTON     1082
#define EXPORT_RETARGET_BUTTON   1083
#define RETARGET_TAKE_LABEL      1084
#define RETARGET_INFO_LABEL      1085
#define RETARGET_JOINT_LIST      1086
#define RETARGET_BONE_LIST       1087
#define MAPPING_ASSIGN_BUTTON    1088
#define MAPPING_UNASSIGN_BUTTON  1089
#define MAPPING_NOTE_LABEL       1090
#define WORKSPACE_MOCAP_TAB      1091
#define WORKSPACE_RETARGET_TAB   1092

// Retarget import transform + position mapping
#define AUTOMAP_POS_BUTTON       1093
#define SIZE_LABEL               1094
#define SIZE_EDIT                1095
#define ROT_LABEL                1096
#define ROT_X_EDIT               1097
#define ROT_Y_EDIT               1098
#define ROT_Z_EDIT               1099
#define APPLY_TRANSFORM_BUTTON   1100
#define RESET_GHOST_BUTTON       1106
#define SYMMETRY_CHECK           1107
#define BVH_EXPORT_CHECK         1108

// Timeline transport
#define FIRST_FRAME_BUTTON       1101
#define PREV_FRAME_BUTTON        1102
#define NEXT_FRAME_BUTTON        1103
#define LAST_FRAME_BUTTON        1104
#define FRAME_INFO_LABEL         1105
#define SHOW_RETARGET_LIVE_CHECK 1109
#define PIPETTE_BUTTON           1110
#define RETARGET_CLEAR_BUTTON    1111
#define NEW_SESSION_BUTTON       1112
#define RETARGET_BONE_TREE       1113
#define LOG_WINDOW               1114
#define LOG_EDIT                 1115

#endif
