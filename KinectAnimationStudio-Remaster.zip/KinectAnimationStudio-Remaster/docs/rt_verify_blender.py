import bpy, math
from mathutils import Matrix, Vector

bpy.ops.import_scene.fbx(filepath=r"C:\Users\Octosniper\AppData\Local\Temp\opencode\rt\rt_out.fbx")

arm = None
for o in bpy.data.objects:
    if o.type == 'ARMATURE':
        arm = o
        break
assert arm, "no armature found"
scene = bpy.context.scene

exp = {}
with open(r"C:\Users\Octosniper\AppData\Local\Temp\opencode\rt\expected.txt") as f:
    for line in f:
        p = line.split()
        if not p: continue
        frame, name = p[0], p[1]
        vals = [float(x) for x in p[2:]]
        exp.setdefault(frame, {})[name] = vals  # pos(3)+rot9+euler3

frames = sorted(exp.keys(), key=lambda t: int(t[1:]))
print("frames:", frames)

R = Matrix(((1,0,0),(0,0,-1),(0,1,0)))  # Rx(+90), file->Blender world

def mat_from_rot9(r):
    return Matrix(( (r[0],r[1],r[2]), (r[3],r[4],r[5]), (r[6],r[7],r[8]) ))

def quat_angle(q1, q2):
    d = q1.dot(q2)
    if d < 0: d = -d
    if d > 1: d = 1
    return 2*math.acos(d)*180/math.pi

worst = 0.0
fail_bones = 0
checked = 0
worst_frame = ""
details = {}

# fcurve values for a pose bone rotation (XYZ euler) at a blender frame
fc_cache = {}
def fcurve_val(name, frame, axis):
    key = (name, axis)
    if key not in fc_cache:
        val = None
        for a in bpy.data.actions:
            if not a.name:
                continue
            for fc in a.fcurves:
                dp = fc.data_path.replace('pose.bones[', '').replace('].rotation_euler', '')
                dp = dp.strip('"')
                if dp == name and fc.array_index == axis:
                    val = fc
                    break
            if val is not None:
                break
        val = val or (None)
        fc_cache[key] = val
    fc = fc_cache[key]
    if fc is None:
        return None
    return fc.evaluate(frame)

for fi, frame in enumerate(frames):
    scene.frame_set(fi + 1)
    bpy.context.view_layer.update()
    fworst = 0.0
    for pb in arm.pose.bones:
        name = pb.name
        if name not in exp[frame]:
            continue
        M = arm.matrix_world @ pb.matrix
        exf = exp[frame][name]
        pos = Vector((exf[0], -exf[2], exf[1])) * 0.01
        posErr = (M.translation - pos).length
        erot = mat_from_rot9(exf[3:12])
        qexp = (R @ erot).to_quaternion()
        qact = M.to_quaternion()
        rotErr = quat_angle(qexp, qact)
        if rotErr > 1.0:
            ew = exf[12:15]
            got_e = [fcurve_val(name, fi + 1, k) for k in (0, 1, 2)]
            details[name] = (frame, rotErr, posErr, ew, got_e, M.translation[:])
        worst = max(worst, rotErr)
        fworst = max(fworst, rotErr)
        checked += 1
        if rotErr > 2.0 or posErr > 0.02:
            fail_bones += 1
            print("FAIL %s %-12s rotErr=%.2fdeg posErr=%.4fm got=(%.3f %.3f %.3f) exp=(%.3f %.3f %.3f)"
                  % (frame, name, rotErr, posErr, M.translation[0], M.translation[1], M.translation[2],
                     pos[0], pos[1], pos[2]))
    if fworst > 0:
        print("  %s worst_rot=%.2fdeg" % (frame, fworst))
print("checked=%d fail_bones=%d worst_rot_err=%.2fdeg worst_frame=%s" % (checked, fail_bones, worst, worst_frame))
for name in sorted(details.keys()):
    frame, rotErr, posErr, ew, got_e, trans = details[name]
    print("  %-12s @%s rotErr=%.2fdeg posErr=%.3fm" % (name, frame, rotErr, posErr))
    print("      fileEuler=(%.2f %.2f %.2f)  blenderFcurve=(%s, %s, %s)"
          % (ew[0], ew[1], ew[2],
             "%.2f" % got_e[0] if got_e[0] is not None else "?",
             "%.2f" % got_e[1] if got_e[1] is not None else "?",
             "%.2f" % got_e[2] if got_e[2] is not None else "?"))
print("BLENDER-VERIFY: %s" % ("OK" if fail_bones==0 else "MISMATCH"))