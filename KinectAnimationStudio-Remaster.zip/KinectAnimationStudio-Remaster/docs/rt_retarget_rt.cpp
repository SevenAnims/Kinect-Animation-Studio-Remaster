// Round-trip verifier for the KAS FBX retarget export math.
// Replicates KRetargeter::computePoseBody + exportRetargetToFile faithfully,
// writes an animation on a synthetic rig, reloads the file and compares the
// FBX-evaluated world transforms to the intended FK world transforms.

#define _USE_MATH_DEFINES
#include <fbxsdk.h>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <string>
#include <map>
using namespace std;

static bool g_fail = false;
static int g_useStatic = 3;   // 0=none, 1=M*S, 2=S*M, 3=M*S^T (correct)
static int g_transpose = 0;   // transpose the final exported world rotation
static int g_zeroPiv = 0;     // zero pre/post rotations on exported nodes
static int g_matrixLocal = 0; // parent-relative local rotation via matrices (not quats)
static int g_allbake = 0;     // full bake: zero static rotations/pre/post, offsets=world diffs, pure M

static void aimRotation(float R[3][3], const float from[3], const float to[3]) {
	R[0][0] = 1; R[0][1] = 0; R[0][2] = 0;
	R[1][0] = 0; R[1][1] = 1; R[1][2] = 0;
	R[2][0] = 0; R[2][1] = 0; R[2][2] = 1;
	float dot = from[0]*to[0] + from[1]*to[1] + from[2]*to[2];
	if (dot > 0.99999f) return;
	float ax[3];
	ax[0] = from[1]*to[2] - from[2]*to[1];
	ax[1] = from[2]*to[0] - from[0]*to[2];
	ax[2] = from[0]*to[1] - from[1]*to[0];
	float angle;
	if (dot < -0.99999f) {
		angle = (float)M_PI;
		if (fabsf(from[0]) < 0.9f) { ax[0]=1; ax[1]=0; ax[2]=0; }
		else { ax[0]=0; ax[1]=1; ax[2]=0; }
		float d = ax[0]*from[0]+ax[1]*from[1]+ax[2]*from[2];
		ax[0]-=d*from[0]; ax[1]-=d*from[1]; ax[2]-=d*from[2];
	} else {
		angle = acosf(dot);
	}
	float len = sqrtf(ax[0]*ax[0]+ax[1]*ax[1]+ax[2]*ax[2]);
	if (len < 1e-6f) return;
	ax[0]/=len; ax[1]/=len; ax[2]/=len;
	float s = sinf(angle*0.5f);
	float qw = cosf(angle*0.5f);
	float qx = ax[0]*s, qy = ax[1]*s, qz = ax[2]*s;
	R[0][0]=1-2*(qy*qy+qz*qz); R[0][1]=  2*(qx*qy-qz*qw); R[0][2]=  2*(qx*qz+qy*qw);
	R[1][0]=  2*(qx*qy+qz*qw); R[1][1]=1-2*(qx*qx+qz*qz); R[1][2]=  2*(qy*qz-qx*qw);
	R[2][0]=  2*(qx*qz-qy*qw); R[2][1]=  2*(qy*qz+qx*qw); R[2][2]=1-2*(qx*qx+qy*qy);
}

static void transpose3(const float in[3][3], float out[3][3]) {
	for (int i=0;i<3;++i) for (int j=0;j<3;++j) out[j][i]=in[i][j];
}
static void mulMat3(const float a[3][3], const float b[3][3], float out[3][3]) {
	float t[3][3];
	for (int i=0;i<3;++i) for (int j=0;j<3;++j)
		t[i][j]=a[i][0]*b[0][j]+a[i][1]*b[1][j]+a[i][2]*b[2][j];
	memcpy(out,t,sizeof(t));
}

static void quatFromMatrix(const float R[3][3], double q[4]) {
	double tr = (double)R[0][0] + R[1][1] + R[2][2];
	if (tr > 0.0) {
		double s = sqrt(tr + 1.0) * 2.0;
		q[0]=(R[2][1]-R[1][2])/s; q[1]=(R[0][2]-R[2][0])/s;
		q[2]=(R[1][0]-R[0][1])/s; q[3]=0.25*s;
	} else if (R[0][0]>R[1][1]&&R[0][0]>R[2][2]) {
		double s = sqrt(1.0+R[0][0]-R[1][1]-R[2][2])*2.0;
		q[0]=0.25*s; q[1]=(R[0][1]+R[1][0])/s;
		q[2]=(R[0][2]+R[2][0])/s; q[3]=(R[2][1]-R[1][2])/s;
	} else if (R[1][1]>R[2][2]) {
		double s = sqrt(1.0+R[1][1]-R[0][0]-R[2][2])*2.0;
		q[0]=(R[0][1]+R[1][0])/s; q[1]=0.25*s;
		q[2]=(R[1][2]+R[2][1])/s; q[3]=(R[0][2]-R[2][0])/s;
	} else {
		double s = sqrt(1.0+R[2][2]-R[0][0]-R[1][1])*2.0;
		q[0]=(R[0][2]+R[2][0])/s; q[1]=(R[1][2]+R[2][1])/s;
		q[2]=0.25*s; q[3]=(R[1][0]-R[0][1])/s;
	}
}

struct Bone { int parent; char name[64]; float lclT[3]; };

struct Rig {
	int n;
	std::vector<Bone> bones;
	std::vector<int> map; // 25 kinect joints -> bone index
	std::vector<float> restPos;   // model space (R*scale*raw)
	std::vector<float> restAxis;
	std::vector<float> staticRest; // 9/bone: raw static WORLD rotation (row-major) from the source
	int rootBoneB;
	float modelUp[3];
};

static FbxAMatrix nodeGlobalMatrixFBX(FbxNode *node, std::map<FbxNode*,FbxAMatrix> &cache) {
	std::map<FbxNode*,FbxAMatrix>::iterator it = cache.find(node);
	if (it != cache.end()) return it->second;
	FbxAMatrix local;
	local.SetTRS(node->LclTranslation.Get(), node->LclRotation.Get(), node->LclScaling.Get());
	FbxAMatrix gm = local;
	if (node->GetParent())
		gm = nodeGlobalMatrixFBX(node->GetParent(), cache) * local;
	cache[node] = gm;
	return gm;
}

static void collectSkeletonNodes(FbxNode *node, std::vector<FbxNode*> &out) {
	for (int i=0;i<node->GetChildCount();++i) {
		FbxNode *c = node->GetChild(i);
		FbxNodeAttribute *attr = c->GetNodeAttribute();
		if (attr && attr->GetAttributeType()==FbxNodeAttribute::eSkeleton) out.push_back(c);
		collectSkeletonNodes(c,out);
	}
}

static FbxScene *buildScene(FbxManager *mgr) {
	FbxScene *scene = FbxScene::Create(mgr, "RtScene");
	scene->GetGlobalSettings().SetAxisSystem(FbxAxisSystem::eMayaYUp);
	scene->GetGlobalSettings().SetSystemUnit(FbxSystemUnit::cm);
	FbxNode *root = scene->GetRootNode();

	struct Def { const char *name; int parent; double t[3]; double pre[3]; double rot[3]; int order; };
	static const Def DEFS[] = {
		{ "Root",        -1, {0,0,0},    {0,0,0},    {0,0,0},  0 },
		{ "spine",        0, {0,85,0},   {0,0,0},    {0,0,0},  0 },
		{ "spine.001",    1, {0,30,0},   {8,0,0},    {0,0,0},  0 },
		{ "spine.002",    2, {0,28,0},   {-6,0,0},   {0,0,0},  0 },
		{ "neck",         3, {0,12,0},   {0,0,0},    {0,0,0},  0 },
		{ "head",         4, {0,10,0},   {0,0,0},    {0,0,0},  0 },
		{ "clavicle.L",   3, {-5,4,8},   {0,0,-10},  {0,0,0},  0 },
		{ "upper_arm.L",  6, {-11,-20,0},{0,0,0},    {-15,0,0},1 },
		{ "forearm.L",    7, {0,-28,0},  {0,0,0},    {0,12,0}, 0 },
		{ "hand.L",       8, {0,-22,0},  {0,0,0},    {0,-25,0},0 },
		{ "clavicle.R",   3, {5,4,8},    {0,0,10},   {0,0,0},  0 },
		{ "upper_arm.R", 10, {11,-20,0}, {0,0,0},    {15,0,0}, 1 },
		{ "forearm.R",   11, {0,-28,0},  {0,0,0},    {0,-12,0},0 },
		{ "hand.R",      12, {0,-22,0},  {0,0,0},    {0,25,0}, 0 },
		{ "thigh.L",      1, {-9,-12,3}, {0,0,0},    {8,0,0},  0 },
		{ "shin.L",      14, {0,-28,0},  {0,0,0},    {0,0,0},  0 },
		{ "foot.L",      15, {0,-34,8},  {0,0,0},    {0,-15,0},0 },
		{ "thigh.R",      1, {9,-12,3},  {0,0,0},    {-8,0,0}, 0 },
		{ "shin.R",      17, {0,-28,0},  {0,0,0},    {0,0,0},  0 },
		{ "foot.R",      18, {0,-34,8},  {0,0,0},    {0,15,0}, 0 },
	};
	int n = sizeof(DEFS)/sizeof(DEFS[0]);
	std::vector<FbxNode*> nodes;
	for (int i=0;i<n;++i) {
		FbxSkeleton *sk = FbxSkeleton::Create(mgr, DEFS[i].name);
		sk->SetSkeletonType((i==0)?FbxSkeleton::eRoot:FbxSkeleton::eLimbNode);
		FbxNode *nn = FbxNode::Create(mgr, DEFS[i].name);
		nn->SetNodeAttribute(sk);
		nn->LclTranslation.Set(FbxDouble3(DEFS[i].t[0],DEFS[i].t[1],DEFS[i].t[2]));
		nn->LclRotation.Set(FbxDouble3(DEFS[i].rot[0],DEFS[i].rot[1],DEFS[i].rot[2]));
		nn->SetPreRotation(FbxNode::eSourcePivot, FbxVector4(DEFS[i].pre[0],DEFS[i].pre[1],DEFS[i].pre[2]));
		FbxEuler::EOrder ords[2] = { FbxEuler::eEulerXYZ, FbxEuler::eEulerYXZ };
		nn->SetRotationOrder(FbxNode::eSourcePivot, ords[DEFS[i].order]);
		FbxNode *par = (DEFS[i].parent>=0)?nodes[DEFS[i].parent]:root;
		par->AddChild(nn);
		nodes.push_back(nn);
	}
	return scene;
}

struct KASSim {
	const Rig &rig;
	float m_importRotMat[3][3], m_importRotMatT[3][3];
	float m_importScale;
	std::vector<float> bonePos, boneWorldMat;

	KASSim(const Rig &r) : rig(r), m_importScale(1.0f) {
		float I[3][3]={{1,0,0},{0,1,0},{0,0,1}};
		memcpy(m_importRotMat,I,sizeof(I));
		memcpy(m_importRotMatT,I,sizeof(I));
	}

	void transformPoint(const float p[3], float out[3]) const {
		float q[3] = { m_importScale*p[0], m_importScale*p[1], m_importScale*p[2] };
		out[0]=m_importRotMat[0][0]*q[0]+m_importRotMat[0][1]*q[1]+m_importRotMat[0][2]*q[2];
		out[1]=m_importRotMat[1][0]*q[0]+m_importRotMat[1][1]*q[1]+m_importRotMat[1][2]*q[2];
		out[2]=m_importRotMat[2][0]*q[0]+m_importRotMat[2][1]*q[1]+m_importRotMat[2][2]*q[2];
	}
	void inverseTransform(const float p[3], float out[3]) const {
		out[0]=m_importRotMatT[0][0]*p[0]+m_importRotMatT[0][1]*p[1]+m_importRotMatT[0][2]*p[2];
		out[1]=m_importRotMatT[1][0]*p[0]+m_importRotMatT[1][1]*p[1]+m_importRotMatT[1][2]*p[2];
		out[2]=m_importRotMatT[2][0]*p[0]+m_importRotMatT[2][1]*p[1]+m_importRotMatT[2][2]*p[2];
		out[0]/=m_importScale; out[1]/=m_importScale; out[2]/=m_importScale;
	}

	void pose(const float apos[25][3], const float base[3], const float anchor[3]) {
		int n = rig.n;
		bonePos.assign(3*n,0.f);
		boneWorldMat.assign(16*n,0.f);
		int rootBone = rig.rootBoneB;
		float modelUp[3] = { rig.modelUp[0], rig.modelUp[1], rig.modelUp[2] };
		float yAxis[3] = {0,1,0}, R_atm[3][3];
		aimRotation(R_atm, yAxis, modelUp);
		float torsoUp[3] = {modelUp[0],modelUp[1],modelUp[2]};
		{
			float sx=apos[1][0]-apos[0][0], sy=apos[1][1]-apos[0][1], sz=apos[1][2]-apos[0][2];
			float l=sqrtf(sx*sx+sy*sy+sz*sz);
			if (l>1e-4f) { sx/=l; sy/=l; sz/=l;
				torsoUp[0]=R_atm[0][0]*sx+R_atm[0][1]*sy+R_atm[0][2]*sz;
				torsoUp[1]=R_atm[1][0]*sx+R_atm[1][1]*sy+R_atm[1][2]*sz;
				torsoUp[2]=R_atm[2][0]*sx+R_atm[2][1]*sy+R_atm[2][2]*sz; }
		}
		float charRoot[3] = { rig.restPos[3*rootBone], rig.restPos[3*rootBone+1], rig.restPos[3*rootBone+2] };
		{ float d[3]={ (base[0]-anchor[0]), (base[1]-anchor[1]), (base[2]-anchor[2]) };
			charRoot[0]+=R_atm[0][0]*d[0]+R_atm[0][1]*d[1]+R_atm[0][2]*d[2];
			charRoot[1]+=R_atm[1][0]*d[0]+R_atm[1][1]*d[1]+R_atm[1][2]*d[2];
			charRoot[2]+=R_atm[2][0]*d[0]+R_atm[2][1]*d[1]+R_atm[2][2]*d[2]; }

		std::vector<float> G(3*n), R(9*n);
		for (int i=0;i<n;++i) {
			float R3[3][3]; memset(R3,0,sizeof(R3));
			R3[0][0]=R3[1][1]=R3[2][2]=1.0f;
			int j = rig.map[i];
			int p = rig.bones[i].parent;
			bool isRoot = (j==0);
			if (isRoot) {
				aimRotation(R3, modelUp, torsoUp);
			}
			int seg[2] = { -1, -1 };
			if (j==1) { seg[0]=1; seg[1]=2; }
			else if (j==2) { seg[0]=2; seg[1]=3; }
			else if (j==4) { seg[0]=4; seg[1]=5; }
			else if (j==5) { seg[0]=5; seg[1]=6; }
			else if (j==6) { seg[0]=6; seg[1]=7; }
			else if (j==8) { seg[0]=8; seg[1]=9; }
			else if (j==9) { seg[0]=9; seg[1]=10; }
			else if (j==10){ seg[0]=10; seg[1]=11; }
			else if (j==12){ seg[0]=12; seg[1]=13; }
			else if (j==13){ seg[0]=13; seg[1]=14; }
			else if (j==14){ seg[0]=14; seg[1]=15; }
			else if (j==16){ seg[0]=16; seg[1]=17; }
			else if (j==17){ seg[0]=17; seg[1]=18; }
			else if (j==18){ seg[0]=18; seg[1]=19; }

			if (!isRoot && seg[0]>=0 && seg[1]>=0) {
				float dx=apos[seg[1]][0]-apos[seg[0]][0];
				float dy=apos[seg[1]][1]-apos[seg[0]][1];
				float dz=apos[seg[1]][2]-apos[seg[0]][2];
				float mx=R_atm[0][0]*dx+R_atm[0][1]*dy+R_atm[0][2]*dz;
				float my=R_atm[1][0]*dx+R_atm[1][1]*dy+R_atm[1][2]*dz;
				float mz=R_atm[2][0]*dx+R_atm[2][1]*dy+R_atm[2][2]*dz;
				float len=sqrtf(mx*mx+my*my+mz*mz);
				if (len>1e-4f) {
					float dir[3]={mx/len,my/len,mz/len};
					float ax3[3]={rig.restAxis[3*i],rig.restAxis[3*i+1],rig.restAxis[3*i+2]};
					aimRotation(R3, ax3, dir);
				}
			} else if (!isRoot && p>=0) {
				memcpy(R3, &R[9*p], sizeof(R3));
			}
			memcpy(&R[9*i], R3, sizeof(R3));

			if (isRoot) {
				G[3*i+0]=charRoot[0]; G[3*i+1]=charRoot[1]; G[3*i+2]=charRoot[2];
			} else if (p>=0) {
				const float *pr=&R[9*p];
				float rv[3]={ rig.restPos[3*i]-rig.restPos[3*p],
					          rig.restPos[3*i+1]-rig.restPos[3*p+1],
					          rig.restPos[3*i+2]-rig.restPos[3*p+2] };
				G[3*i+0]=G[3*p+0]+pr[0]*rv[0]+pr[1]*rv[1]+pr[2]*rv[2];
				G[3*i+1]=G[3*p+1]+pr[3]*rv[0]+pr[4]*rv[1]+pr[5]*rv[2];
				G[3*i+2]=G[3*p+2]+pr[6]*rv[0]+pr[7]*rv[1]+pr[8]*rv[2];
			} else {
				G[3*i+0]=rig.restPos[3*i]; G[3*i+1]=rig.restPos[3*i+1]; G[3*i+2]=rig.restPos[3*i+2];
			}
		}
		bonePos.assign(G.begin(),G.end());
		for (int i=0;i<n;++i) {
			const float *Rr=&R[9*i];
			float W[16]; memset(W,0,sizeof(W));
			W[0]=Rr[0]; W[1]=Rr[1]; W[2]=Rr[2]; W[3]=bonePos[3*i];
			W[4]=Rr[3]; W[5]=Rr[4]; W[6]=Rr[5]; W[7]=bonePos[3*i+1];
			W[8]=Rr[6]; W[9]=Rr[7]; W[10]=Rr[8]; W[11]=bonePos[3*i+2];
			W[15]=1.0f;
			memcpy(&boneWorldMat[16*i], W, sizeof(W));
		}
	}
};

static void applyTransformation(FbxAnimLayer *layer, FbxNode *node, FbxDouble3 v, FbxTime t, bool isT) {
	FbxAnimCurve *xc,*yc,*zc;
	FbxProperty *p;
	if (isT) { xc=node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_X, true);
	           yc=node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Y, true);
	           zc=node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Z, true); }
	else { xc=node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_X, true);
	       yc=node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Y, true);
	       zc=node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Z, true); }
	xc->KeyModifyBegin(); int ki=xc->KeyAdd(t); xc->KeySetValue(ki, (float)v[0]); xc->KeyModifyEnd();
	yc->KeyModifyBegin(); ki=yc->KeyAdd(t); yc->KeySetValue(ki, (float)v[1]); yc->KeyModifyEnd();
	zc->KeyModifyBegin(); ki=zc->KeyAdd(t); zc->KeySetValue(ki, (float)v[2]); zc->KeyModifyEnd();
}

int main(int argc, char **argv) {
	if (argc>1) g_useStatic = atoi(argv[1]);
	if (argc>2) g_transpose = atoi(argv[2]);
	if (argc>3) g_zeroPiv = atoi(argv[3]);
	if (argc>4) g_matrixLocal = atoi(argv[4]);
	if (argc>5) g_allbake = atoi(argv[5]);
	printf("USESTATIC=%d TRANSPOSE=%d ZEROPIV=%d MATLOCAL=%d ALLBAKE=%d\n", g_useStatic, g_transpose, g_zeroPiv, g_matrixLocal, g_allbake);
	FbxManager *mgr = FbxManager::Create();
	FbxIOSettings *ios = FbxIOSettings::Create(mgr, IOSROOT);
	mgr->SetIOSettings(ios);

	FbxScene *scene = buildScene(mgr);
	{
		FbxAxisSystem ax = scene->GetGlobalSettings().GetAxisSystem();
		int ups=0, frs=0;
		FbxAxisSystem::EUpVector up = ax.GetUpVector(ups);
		FbxAxisSystem::EFrontVector fr = ax.GetFrontVector(frs);
		printf("AXIS at build:   up=%d fr=%d coor=%d\n", (int)up, (int)fr, (int)ax.GetCoorSystem());
	}
	// Save + reload, exactly like exportRetargetToFile does with the source.
	{
		int fmt = mgr->GetIOPluginRegistry()->FindWriterIDByDescription("FBX binary (*.fbx)");
		if (fmt>=0) {
			FbxExporter *ex = FbxExporter::Create(mgr, "");
			if (ex->Initialize("src.fbx", fmt, mgr->GetIOSettings())) ex->Export(scene);
			ex->Destroy();
		}
	}
	scene->Destroy();
	scene = FbxScene::Create(mgr, "ImportScene");
	{
		FbxImporter *imp = FbxImporter::Create(mgr, "");
		bool ok = imp->Initialize("src.fbx", -1, mgr->GetIOSettings());
		if (ok) ok = imp->Import(scene);
		imp->Destroy();
		if (!ok) { printf("RELOAD FAILED\n"); mgr->Destroy(); return 1; }
	}
	{
		FbxAxisSystem ax = scene->GetGlobalSettings().GetAxisSystem();
		int ups=0, frs=0;
		FbxAxisSystem::EUpVector up = ax.GetUpVector(ups);
		FbxAxisSystem::EFrontVector fr = ax.GetFrontVector(frs);
		printf("AXIS after reload: up=%d fr=%d coor=%d\n", (int)up, (int)fr, (int)ax.GetCoorSystem());
	}
	std::vector<FbxNode*> nodes;
	collectSkeletonNodes(scene->GetRootNode(), nodes);
	if (g_zeroPiv) {
		// Blender (unlike the FBX SDK world transform) folds the stored
		// pre/post rotations into the bone matrix. The SDK never evaluates
		// them, so zeroing them here cannot change the SDK round-trip but
		// makes Blender's interpretation match the SDK's exactly.
		for (FbxNode *nd : nodes) {
			nd->SetPreRotation(FbxNode::eSourcePivot, FbxVector4(0,0,0,1));
			nd->SetPostRotation(FbxNode::eSourcePivot, FbxVector4(0,0,0,1));
		}
	}
	Rig rig;
	rig.n = (int)nodes.size();
	rig.bones.resize(rig.n);
	rig.map.assign(rig.n, -1);
	std::map<FbxNode*,int> idx;
	for (int i=0;i<rig.n;++i) idx[nodes[i]]=i;
	std::map<FbxNode*,FbxAMatrix> gcache;
	rig.restPos.assign(3*rig.n,0.f);
	rig.restAxis.assign(3*rig.n,0.f);
	rig.staticRest.assign(9*rig.n,0.f);
	const char *mapTo[25] = {0};
	mapTo[0]="spine"; mapTo[1]="spine.001"; mapTo[2]="spine.002"; mapTo[3]="neck";
	mapTo[8]="upper_arm.L"; mapTo[9]="forearm.L"; mapTo[10]="hand.L";
	mapTo[4]="upper_arm.R"; mapTo[5]="forearm.R"; mapTo[6]="hand.R";
	mapTo[12]="thigh.L"; mapTo[13]="shin.L"; mapTo[14]="foot.L";
	mapTo[16]="thigh.R"; mapTo[17]="shin.R"; mapTo[18]="foot.R";
	for (int i=0;i<rig.n;++i) {
		rig.bones[i].parent=-1;
		strcpy_s(rig.bones[i].name, nodes[i]->GetName());
		for (FbxNode *p=nodes[i]->GetParent(); p; p=p->GetParent()) {
			std::map<FbxNode*,int>::iterator it=idx.find(p);
			if (it!=idx.end()) { rig.bones[i].parent=it->second; break; }
		}
		FbxAMatrix gm = nodeGlobalMatrixFBX(nodes[i], gcache);
		FbxVector4 t=gm.GetT();
		rig.restPos[3*i]=(float)t[0]; rig.restPos[3*i+1]=(float)t[1]; rig.restPos[3*i+2]=(float)t[2];
		rig.staticRest[9*i+0]=(float)gm[0][0]; rig.staticRest[9*i+1]=(float)gm[0][1]; rig.staticRest[9*i+2]=(float)gm[0][2];
		rig.staticRest[9*i+3]=(float)gm[1][0]; rig.staticRest[9*i+4]=(float)gm[1][1]; rig.staticRest[9*i+5]=(float)gm[1][2];
		rig.staticRest[9*i+6]=(float)gm[2][0]; rig.staticRest[9*i+7]=(float)gm[2][1]; rig.staticRest[9*i+8]=(float)gm[2][2];
		for (int j=0;j<25;++j) if (mapTo[j] && strcmp(mapTo[j], rig.bones[i].name)==0) rig.map[i]=j;
	}
	for (int i=0;i<rig.n;++i) {
		float dx=0,dy=0,dz=0;
		int fc=-1;
		for (int k=i+1;k<rig.n;++k) if (rig.bones[k].parent==i) { fc=k; break; }
		int p=rig.bones[i].parent;
		if (fc>=0){ dx=rig.restPos[3*fc]-rig.restPos[3*i]; dy=rig.restPos[3*fc+1]-rig.restPos[3*i+1]; dz=rig.restPos[3*fc+2]-rig.restPos[3*i+2]; }
		else if (p>=0){ dx=rig.restPos[3*i]-rig.restPos[3*p]; dy=rig.restPos[3*i+1]-rig.restPos[3*p+1]; dz=rig.restPos[3*i+2]-rig.restPos[3*p+2]; }
		float l=sqrtf(dx*dx+dy*dy+dz*dz);
		if (l>1e-5f){ rig.restAxis[3*i]=dx/l; rig.restAxis[3*i+1]=dy/l; rig.restAxis[3*i+2]=dz/l; }
		else rig.restAxis[3*i+1]=1.0f;
	}
	rig.rootBoneB=-1;
	for (int i=0;i<rig.n;++i) if (rig.map[i]==0) { rig.rootBoneB=i; break; }

	{
		float sx=0,sy=0,sz=0;
		int r=rig.rootBoneB;
		for (int c=0;c<rig.n;++c) if (rig.bones[c].parent==r) {
			sx+=rig.restPos[3*c]-rig.restPos[3*r];
			sy+=rig.restPos[3*c+1]-rig.restPos[3*r+1];
			sz+=rig.restPos[3*c+2]-rig.restPos[3*r+2];
		}
		float l=sqrtf(sx*sx+sy*sy+sz*sz);
		if (l>1e-4f){ rig.modelUp[0]=sx/l; rig.modelUp[1]=sy/l; rig.modelUp[2]=sz/l; }
		else { rig.modelUp[0]=0; rig.modelUp[1]=1; rig.modelUp[2]=0; }
	}

	{
		bool diff=false;
		for (int i=0;i<rig.n;++i) {
			FbxAMatrix ev = nodes[i]->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot);
			FbxVector4 t=ev.GetT();
			double d = sqrt(pow(t[0]-rig.restPos[3*i],2)+pow(t[1]-rig.restPos[3*i+1],2)+pow(t[2]-rig.restPos[3*i+2],2));
			if (d>0.1) { diff=true; printf("POSDIFF %s: rt=(%g %g %g) ev=(%g %g %g)\n", rig.bones[i].name, rig.restPos[3*i],rig.restPos[3*i+1],rig.restPos[3*i+2], t[0],t[1],t[2]); }
		}
		if (!diff) printf("OK: SetTRS global positions == EvaluateGlobalTransform positions\n");
	}

	// ---- PROBE 2: what rotation order does the SDK use to evaluate LclRotation? ----
	{
		for (int probeIdx = 0; probeIdx < rig.n; ++probeIdx) {
			FbxNode *nd = nodes[probeIdx];
			if (strcmp(rig.bones[probeIdx].name, "upper_arm.L")!=0) continue;
			FbxEuler::EOrder stord; nd->GetRotationOrder(FbxNode::eSourcePivot, stord);
			printf("PROBE2 stored order=%d\n", (int)stord);
			nd->LclRotation.Set(FbxDouble3(10,20,30));
			FbxAMatrix w = nd->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot);
			FbxAMatrix wp; if (nd->GetParent()) wp = nd->GetParent()->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot); else wp.SetIdentity();
			FbxAMatrix local = wp.Inverse() * w;
			for (int o = FbxEuler::eEulerXYZ; o <= FbxEuler::eSphericXYZ; ++o) {
				FbxAMatrix m; m.SetR(FbxDouble3(10,20,30), (FbxEuler::EOrder)o);
				FbxQuaternion qa = local.GetQ(), qb = m.GetQ();
				double dot = qa[0]*qb[0]+qa[1]*qb[1]+qa[2]*qb[2]+qa[3]*qb[3];
				if (dot<0) dot=-dot; if (dot>1) dot=1;
				double deg = 2*acos(dot)*180.0/M_PI;
				printf("   evalLocal vs SetR(order=%d): diff=%.3fdeg\n", o, deg);
			}
			nd->LclRotation.Set(FbxDouble3(0,0,0));
		}
	}

	// ---- PROBE: how does the SDK apply pre/post rotation? ----
	{
		for (int probeIdx = 0; probeIdx < rig.n; ++probeIdx) {
			FbxNode *nd = nodes[probeIdx];
			FbxVector4 pre = nd->GetPreRotation(FbxNode::eSourcePivot);
			FbxVector4 post = nd->GetPostRotation(FbxNode::eSourcePivot);
			if (pre!=FbxVector4(0,0,0,1) || post!=FbxVector4(0,0,0,1)) {
				FbxEuler::EOrder ord; nd->GetRotationOrder(FbxNode::eSourcePivot, ord);
				// rest local rotation = Rpre * LclRrest(0) * Rpost  (evaluated)
				FbxAMatrix w  = nd->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot);
				FbxAMatrix wp;
				if (nd->GetParent()) wp = nd->GetParent()->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot);
				else wp.SetIdentity();
				FbxAMatrix local = wp.Inverse() * w;
				FbxQuaternion qEval = local.GetQ();
				// our reconstruction preM*I*postM via SetR
				FbxAMatrix preM, postM; preM.SetR(pre); postM.SetR(post);
				FbxAMatrix ours = preM * postM;
				FbxQuaternion qOurs = ours.GetQ();
				double dot = qEval[0]*qOurs[0]+qEval[1]*qOurs[1]+qEval[2]*qOurs[2]+qEval[3]*qOurs[3];
				if (dot<0) dot=-dot; if (dot>1) dot=1;
				double deg = 2*acos(dot)*180.0/M_PI;
				printf("PROBE %-12s pre=(%g,%g,%g) post=(%g,%g,%g) order=%d restLocalQ=(%.4f %.4f %.4f %.4f) oursQ=(%.4f %.4f %.4f %.4f) diff=%.2fdeg\n",
					rig.bones[probeIdx].name, pre[0],pre[1],pre[2], post[0],post[1],post[2], (int)ord,
					qEval[0],qEval[1],qEval[2],qEval[3], qOurs[0],qOurs[1],qOurs[2],qOurs[3], deg);
			}
		}
	}

	// Motion generator: N frames of smooth limb motion. Only the DIRECTIONS
	// matter (FK lengths come from restPos). Right arm / left leg in phase,
	// left arm / right leg opposite phase; torso sways side to side.
	static const int NF = 16;
	auto makeFrame = [](int fi, float apos[25][3]) {
		double T = 2.0*M_PI*fi/(double)NF;
		double s=sin(T), c=cos(T);
		double bob = 0.02*s;
		apos[0][0]=(float)(0.03*s); apos[0][1]=(float)(0.90+bob); apos[0][2]=(float)(0.02*s);
		apos[1][0]=(float)(0.02*s); apos[1][1]=(float)(1.00+bob); apos[1][2]=(float)(0.05*c);
		apos[2][0]=(float)(0.015*s); apos[2][1]=(float)(1.15+bob); apos[2][2]=(float)(0.09*c);
		apos[3][0]=(float)(0.01*s); apos[3][1]=(float)(1.26+bob); apos[3][2]=(float)(0.10*c);
		float Sy=(float)(1.05+bob);
		// right arm (shoulder 8, elbow 9, wrist 10)
		{
			double dx=0.35*c, dy=-0.55, dz=0.30*s, l=sqrt(dx*dx+dy*dy+dz*dz);
			dx/=l; dy/=l; dz/=l;
			apos[8][0]=0.18f; apos[8][1]=Sy; apos[8][2]=0.03f;
			apos[9][0]=(float)(0.18+dx*0.28); apos[9][1]=(float)(Sy+dy*0.28); apos[9][2]=(float)(0.03+dz*0.28);
			apos[10][0]=(float)(0.18+dx*0.55); apos[10][1]=(float)(Sy+dy*0.55); apos[10][2]=(float)(0.03+dz*0.55);
			for (int k=0;k<3;++k) apos[11][k]=apos[10][k];
		}
		// left arm (4,5,6), opposite phase
		{
			double dx=0.35*c, dy=-0.55, dz=-0.30*s, l=sqrt(dx*dx+dy*dy+dz*dz);
			dx/=l; dy/=l; dz/=l;
			apos[4][0]=-0.18f; apos[4][1]=Sy; apos[4][2]=0.03f;
			apos[5][0]=(float)(-0.18+dx*0.28); apos[5][1]=(float)(Sy+dy*0.28); apos[5][2]=(float)(0.03+dz*0.28);
			apos[6][0]=(float)(-0.18+dx*0.55); apos[6][1]=(float)(Sy+dy*0.55); apos[6][2]=(float)(0.03+dz*0.55);
			for (int k=0;k<3;++k) apos[7][k]=apos[6][k];
		}
		// right leg swung forward with s, left leg with -s
		{
			double dx=0.05*s, dy=-0.55, dz=0.30*s, l=sqrt(dx*dx+dy*dy+dz*dz);
			dx/=l; dy/=l; dz/=l;
			apos[16][0]=0.09f; apos[16][1]=(float)(0.85+bob); apos[16][2]=0.01f;
			apos[17][0]=(float)(0.09+dx*0.30); apos[17][1]=(float)(0.85+bob+dy*0.30); apos[17][2]=(float)(0.01+dz*0.30);
			apos[18][0]=(float)(0.09+dx*0.62); apos[18][1]=(float)(0.85+bob+dy*0.62); apos[18][2]=(float)(0.01+dz*0.62);
			for (int k=0;k<3;++k) apos[19][k]=apos[18][k];
		}
		{
			double dx=-0.05*s, dy=-0.55, dz=-0.30*s, l=sqrt(dx*dx+dy*dy+dz*dz);
			dx/=l; dy/=l; dz/=l;
			apos[12][0]=-0.09f; apos[12][1]=(float)(0.85+bob); apos[12][2]=0.01f;
			apos[13][0]=(float)(-0.09+dx*0.30); apos[13][1]=(float)(0.85+bob+dy*0.30); apos[13][2]=(float)(0.01+dz*0.30);
			apos[14][0]=(float)(-0.09+dx*0.62); apos[14][1]=(float)(0.85+bob+dy*0.62); apos[14][2]=(float)(0.01+dz*0.62);
			for (int k=0;k<3;++k) apos[15][k]=apos[14][k];
		}
	};

	KASSim kas(rig);
	float anchor[3] = { 0.0f, 1.0f, 0.0f };

	FbxAnimStack *st = FbxAnimStack::Create(scene, "Retarget Animation");
	FbxAnimLayer *layer = FbxAnimLayer::Create(scene, "Layer");
	st->AddMember(layer);
	scene->SetCurrentAnimationStack(st);
	scene->GetGlobalSettings().SetTimeMode(FbxTime::eFrames30);

	int nBones = rig.n;
	FbxNode *rootNode = nodes[rig.rootBoneB];
	FbxAMatrix rootParentWorld, rootParentInv;
	FbxNode *rpar = rootNode->GetParent();
	if (rpar) { rootParentWorld = rpar->EvaluateGlobalTransform(FbxTime(0), FbxNode::eSourcePivot); rootParentInv = rootParentWorld.Inverse(); }
	else rootParentInv.SetIdentity();

	if (g_allbake) {
		// Full-bake rest: no static rotations, no pre/post, world-diff offsets.
		// The translation animation goes on the KAS root bone only; every other
		// bone keeps a constant world-space offset vector.
		KASSim restSim(rig);
		for (int i=0;i<rig.n;++i) {
			FbxNode *nd=nodes[i];
			nd->SetPreRotation(FbxNode::eSourcePivot, FbxVector4(0,0,0,1));
			nd->SetPostRotation(FbxNode::eSourcePivot, FbxVector4(0,0,0,1));
			nd->LclRotation.Set(FbxDouble3(0,0,0));
			float po[3];
			restSim.inverseTransform(&rig.restPos[3*i], po);
			if (i==rig.rootBoneB) {
				FbxVector4 localPos = rootParentInv.MultT(FbxVector4(po[0],po[1],po[2]));
				nd->LclTranslation.Set(FbxDouble3(localPos[0],localPos[1],localPos[2]));
			} else {
				int p=rig.bones[i].parent;
				if (p>=0) {
					float fo[3];
					restSim.inverseTransform(&rig.restPos[3*p], fo);
					nd->LclTranslation.Set(FbxDouble3(po[0]-fo[0], po[1]-fo[1], po[2]-fo[2]));
				} else {
					nd->LclTranslation.Set(FbxDouble3(po[0],po[1],po[2]));
				}
			}
		}
	}

	std::vector<float> prevRot(3*nBones,0.f);
	std::vector<bool> hasPrev(nBones,false);

	auto exportFrame = [&](float apos[25][3], const float base[3], FbxLongLong ms, const char *tag) {
		kas.pose(apos, base, anchor);
		std::vector<float> origPos(3*nBones), origMat(16*nBones);
for (int i=0;i<nBones;++i) {
				const float *pos=&kas.bonePos[3*i];
				const float *W=&kas.boneWorldMat[16*i];
				float po[3]; kas.inverseTransform(pos, po);
				origPos[3*i]=po[0]; origPos[3*i+1]=po[1]; origPos[3*i+2]=po[2];
				float Ro[3][3];
				for (int r=0;r<3;++r) for (int c=0;c<3;++c) {
					double acc=0;
					for (int a=0;a<3;++a) {
						double wc = kas.m_importRotMatT[r][0]*W[a] + kas.m_importRotMatT[r][1]*W[4+a] + kas.m_importRotMatT[r][2]*W[8+a];
						acc += wc * kas.m_importRotMat[a][c];
					}
					Ro[r][c]=(float)acc;
				}
				// The file replays world = offsets x local rotations. The FK
				// positions of KAS come from the source's STATIC bone
				// orientations, so the exported world rotation must also carry
				// the static raw rest orientation, else the offsets recompose a
				// different rest pose and every rolled bone twists. (KAS does
				// NOT bake this: at rest its FK = authored restPos.)
				// g_allbake replaces this by baking the static into the offsets
				// (world-diff rest) and zeroing the rest rotations, so the
				// exported rotation is the pure conjugated model rotation.
				if (g_useStatic && !g_allbake) {
					const float *S=&rig.staticRest[9*i];
					float S0[3][3]={{S[0],S[1],S[2]},{S[3],S[4],S[5]},{S[6],S[7],S[8]}};
					float T2[3][3];
					if (g_useStatic==2) mulMat3(S0, Ro, T2);            // S*M
					else if (g_useStatic==3) {                          // M*S^T
						float St[3][3]={{S0[0][0],S0[1][0],S0[2][0]},{S0[0][1],S0[1][1],S0[2][1]},{S0[0][2],S0[1][2],S0[2][2]}};
						mulMat3(Ro, St, T2);
					}
					else mulMat3(Ro, S0, T2);                           // M*S
					for (int r=0;r<3;++r) for (int c=0;c<3;++c) Ro[r][c]=T2[r][c];
				}
				if (g_transpose) {
					float Tt[3][3];
					transpose3(Ro, Tt);
					for (int r=0;r<3;++r) for (int c=0;c<3;++c) Ro[r][c]=Tt[r][c];
				}
				origMat[16*i+0]=Ro[0][0]; origMat[16*i+1]=Ro[0][1]; origMat[16*i+2]=Ro[0][2];
			origMat[16*i+4]=Ro[1][0]; origMat[16*i+5]=Ro[1][1]; origMat[16*i+6]=Ro[1][2];
			origMat[16*i+8]=Ro[2][0]; origMat[16*i+9]=Ro[2][1]; origMat[16*i+10]=Ro[2][2];
			origMat[16*i+15]=1.0f;
		}
		FbxTime t; t.SetMilliSeconds(ms);
		FILE *expf = fopen("expected.txt", "a");
		for (int i=0;i<nBones;++i) {
			FbxNode *node=nodes[i];
			const float *W=&origMat[16*i];
			float R[3][3]={{W[0],W[1],W[2]},{W[4],W[5],W[6]},{W[8],W[9],W[10]}};
			double qb[4]; quatFromMatrix(R,qb);
			FbxQuaternion qBone(qb[0],qb[1],qb[2],qb[3]);
			FbxQuaternion qLocal=qBone;
			int p=rig.bones[i].parent;
			if (g_matrixLocal) {
				// Parent-relative via matrices: L = P^T * C (row-major,
				// column-vector convention), no quaternion round-trip.
				float L[3][3];
				float C3[3][3]={{W[0],W[1],W[2]},{W[4],W[5],W[6]},{W[8],W[9],W[10]}};
				if (p<0) {
					FbxAMatrix rw = rootParentWorld;
					rw.SetT(FbxVector4(0,0,0,0));
					rw = rw.Transpose();
					float PT[3][3];
					for (int r=0;r<3;++r) for (int c=0;c<3;++c) PT[r][c]=(float)rw[r][c];
					mulMat3(PT, C3, L);
				} else {
					const float *PW=&origMat[16*p];
					float PR[3][3]={{PW[0],PW[1],PW[2]},{PW[4],PW[5],PW[6]},{PW[8],PW[9],PW[10]}};
					float PT[3][3]; transpose3(PR, PT);
					mulMat3(PT, C3, L);
				}
				double ql[4]; quatFromMatrix(L, ql);
				qLocal = FbxQuaternion(ql[0],ql[1],ql[2],ql[3]);
			} else if (p>=0) {
				const float *PW=&origMat[16*p];
				float PR[3][3]={{PW[0],PW[1],PW[2]},{PW[4],PW[5],PW[6]},{PW[8],PW[9],PW[10]}};
				double qp[4]; quatFromMatrix(PR,qp);
				FbxQuaternion qParent(qp[0],qp[1],qp[2],qp[3]);
				qParent.Inverse();
				qLocal = qParent * qBone;
			} else {
				FbxQuaternion qParent(rootParentWorld.GetQ());
				qParent.Inverse();
				qLocal = qParent * qBone;
			}
			FbxEuler::EOrder order = FbxEuler::eEulerXYZ;
			node->SetRotationOrder(FbxNode::eSourcePivot, order);
			(void)order;
			FbxAMatrix comp; comp.SetQ(qLocal);
			FbxVector4 euler = comp.GetR((int)order);
			float ex=(float)euler[0], ey=(float)euler[1], ez=(float)euler[2];
			if (hasPrev[i]) {
				const float *pe=&prevRot[3*i];
				while (ex-pe[0]>180) ex-=360; while (ex-pe[0]<-180) ex+=360;
				while (ey-pe[1]>180) ey-=360; while (ey-pe[1]<-180) ey+=360;
				while (ez-pe[2]>180) ez-=360; while (ez-pe[2]<-180) ez+=360;
			}
			prevRot[3*i]=ex; prevRot[3*i+1]=ey; prevRot[3*i+2]=ez; hasPrev[i]=true;
			if (expf) fprintf(expf, "%s %s %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f\n",
				tag, rig.bones[i].name,
				origPos[3*i], origPos[3*i+1], origPos[3*i+2],
				origMat[16*i], origMat[16*i+1], origMat[16*i+2],
				origMat[16*i+4], origMat[16*i+5], origMat[16*i+6],
				origMat[16*i+8], origMat[16*i+9], origMat[16*i+10],
				ex, ey, ez);
			applyTransformation(layer,node,FbxDouble3(ex,ey,ez),t,false);
			if (g_allbake ? (i==rig.rootBoneB) : (p<0)) {
				FbxVector4 localPos = rootParentInv.MultT(FbxVector4(origPos[3*i],origPos[3*i+1],origPos[3*i+2]));
				applyTransformation(layer,node,FbxDouble3(localPos[0],localPos[1],localPos[2]),t,true);
			}
		}
		if (expf) fclose(expf);

		printf("--- frame %s ---\n", tag);
		double worstE=0, worstP=0; const char *worstN="";
		for (int i=0;i<rig.n;++i) {
			FbxAMatrix ev = nodes[i]->EvaluateGlobalTransform(t, FbxNode::eSourcePivot);
			const float *W=&origMat[16*i];
			float Rm[3][3]={{W[0],W[1],W[2]},{W[4],W[5],W[6]},{W[8],W[9],W[10]}};
			double qe[4]; quatFromMatrix(Rm,qe);
			FbxQuaternion qExp(qe[0],qe[1],qe[2],qe[3]);
			FbxQuaternion qAct = ev.GetQ();
			double dot = qExp[0]*qAct[0]+qExp[1]*qAct[1]+qExp[2]*qAct[2]+qExp[3]*qAct[3];
			if (dot<0) dot=-dot;
			if (dot>1.0) dot=1.0;
			double err = 2.0*acos(dot)*180.0/M_PI;
			FbxVector4 te = ev.GetT();
			double dxp=te[0]-origPos[3*i], dyp=te[1]-origPos[3*i+1], dzp=te[2]-origPos[3*i+2];
			double perr=sqrt(dxp*dxp+dyp*dyp+dzp*dzp);
			if (err>1.0 || perr>0.5) g_fail=true;
			if (err>worstE) { worstE=err; worstN=rig.bones[i].name; }
			if (perr>worstP) worstP=perr;
			if (i==0 || err>1.0 || perr>0.5) {
				printf("%-12s rotErr=%.2fdeg posErr=%.4f ev=(%.2f %.2f %.2f) exp=(%.2f %.2f %.2f)\n",
					rig.bones[i].name, err, perr, te[0],te[1],te[2], origPos[3*i],origPos[3*i+1],origPos[3*i+2]);
			}
		}
		printf("SDK worst: %s rotErr=%.3fdeg posErr=%.4f\n", worstN, worstE, worstP);
	};

	float apos[25][3] = {{0}};
	for (int fi = 0; fi < NF; ++fi) {
		makeFrame(fi, apos);
		double T = 2.0*M_PI*fi/(double)NF;
		float base[3] = { (float)(0.03*sin(T)), 1.0f, (float)(0.025*cos(T)) };
		if (fi==0) { anchor[0]=base[0]; anchor[1]=base[1]; anchor[2]=base[2]; }
		char tag[8];
		sprintf_s(tag, "F%02d", fi);
		exportFrame(apos, base, 1 + 33*fi, tag);
	}

	int fmt = mgr->GetIOPluginRegistry()->FindWriterIDByDescription("FBX binary (*.fbx)");
	if (fmt>=0) {
		FbxExporter *ex = FbxExporter::Create(mgr, "");
		if (ex->Initialize("rt_out.fbx", fmt, mgr->GetIOSettings())) ex->Export(scene);
		ex->Destroy();
	}

	printf("%s\n", g_fail ? "ROUND-TRIP: MISMATCH" : "ROUND-TRIP: OK");

	mgr->Destroy();
	return g_fail?1:0;
}
